<?php

session_start();
require("conexion.php");

header("Content-Type: application/json");

if(!isset($_SESSION["pedido"])){

    echo json_encode([
        "ok"=>false,
        "mensaje"=>"No existe pedido activo"
    ]);

    exit;
}

$idPedido = $_SESSION["pedido"];

$accion = $_POST["accion"] ?? "";

switch($accion){

    //==================================================
    // AGREGAR PRODUCTO
    //==================================================

    case "agregar":

        $codigo = $_POST["codigo"] ?? "";

        // Buscar producto
        $sqlProducto = "SELECT * 
                        FROM productos 
                        WHERE codigo='$codigo'";

        $resultadoProducto = $conn->query($sqlProducto);

        if($resultadoProducto->num_rows == 0){

            echo json_encode([
                "ok"=>false,
                "mensaje"=>"Producto no encontrado"
            ]);

            exit;
        }

        $producto = $resultadoProducto->fetch_assoc();

        // Stock disponible
        $stock = (int)$producto["stock"];

        // Verificar si ya existe en el carrito
        $sqlExiste = "SELECT *
                      FROM carrito
                      WHERE pedidos_id='$idPedido'
                      AND productos_codigo='$codigo'";

        $resultadoExiste = $conn->query($sqlExiste);

        // Cantidad actual
        $cantidadActual = 0;

        if($resultadoExiste->num_rows > 0){

            $fila = $resultadoExiste->fetch_assoc();

            $cantidadActual = (int)$fila["cantidad"];
        }

        // Nueva cantidad
        $nuevaCantidad = $cantidadActual + 1;

        //==================================================
        // VERIFICAR STOCK
        //==================================================

        if($nuevaCantidad > $stock){

            echo json_encode([
                "ok"=>false,
                "mensaje"=>"No hay suficiente stock. Solo hay ".$stock." unidades disponibles.",
                "stock"=>$stock,
                "cantidad"=>$cantidadActual
            ]);

            exit;
        }

        // Calcular subtotal
        $subtotal = $nuevaCantidad * (int)$producto["precio"];


        //==================================================
        // ACTUALIZAR SI YA EXISTE
        //==================================================

        if($cantidadActual > 0){

            $sql = "UPDATE carrito
                    SET cantidad='$nuevaCantidad',
                        costototal='$subtotal'
                    WHERE pedidos_id='$idPedido'
                    AND productos_codigo='$codigo'";

        }else{

            //==================================================
            // INSERTAR SI NO EXISTE
            //==================================================

            $sql = "INSERT INTO carrito
                    (
                        pedidos_id,
                        productos_codigo,
                        cantidad,
                        costototal
                    )
                    VALUES
                    (
                        '$idPedido',
                        '$codigo',
                        1,
                        '".$producto["precio"]."'
                    )";
        }


        //==================================================
        // EJECUTAR
        //==================================================

        if($conn->query($sql)){

            echo json_encode([
                "ok"=>true,
                "mensaje"=>"Producto agregado correctamente",
                "stock"=>$stock,
                "cantidad"=>$nuevaCantidad
            ]);

        }else{

            echo json_encode([
                "ok"=>false,
                "mensaje"=>$conn->error
            ]);

        }

    break;


    //==================================================
    // MOSTRAR CARRITO
    //==================================================

    case "mostrar":

        $sql = "SELECT
                    c.productos_codigo,
                    c.cantidad,
                    c.costototal,
                    p.nombre,
                    p.precio,
                    p.imagen,
                    p.stock
                FROM carrito c
                INNER JOIN productos p
                ON c.productos_codigo = p.codigo
                WHERE c.pedidos_id='$idPedido'";

        $resultado = $conn->query($sql);

        $carrito = [];

        while($fila = $resultado->fetch_assoc()){

            $carrito[] = $fila;
        }

        echo json_encode($carrito);

    break;


    //==================================================
    // VACIAR CARRITO
    //==================================================

    case "vaciar":

        $sql = "DELETE FROM carrito
                WHERE pedidos_id='$idPedido'";

        if($conn->query($sql)){

            echo json_encode([
                "ok"=>true,
                "mensaje"=>"Carrito vaciado correctamente"
            ]);

        }else{

            echo json_encode([
                "ok"=>false,
                "mensaje"=>$conn->error
            ]);

        }

    break;


    //==================================================
    // ACCIÓN NO RECONOCIDA
    //==================================================

    default:

        echo json_encode([
            "ok"=>false,
            "mensaje"=>"Acción no válida"
        ]);

    break;
}

$conn->close();

?>